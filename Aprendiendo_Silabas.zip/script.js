const syllableGroups = [
  ["MA","ME","MI","MO","MU"],["PA","PE","PI","PO","PU"],
  ["LA","LE","LI","LO","LU"],["SA","SE","SI","SO","SU"],
  ["TA","TE","TI","TO","TU"],["BA","BE","BI","BO","BU"],
  ["CA","CE","CI","CO","CU"],["DA","DE","DI","DO","DU"],
  ["FA","FE","FI","FO","FU"],["GA","GE","GI","GO","GU"],
  ["NA","NE","NI","NO","NU"],["RA","RE","RI","RO","RU"]
];

const words = [
  ["🐱","GATO","GA-TO"],["🐶","PATO","PA-TO"],["🌙","LUNA","LU-NA"],
  ["⚽","PELOTA","PE-LO-TA"],["🍎","MANZANA","MAN-ZA-NA"],["🏠","CASA","CA-SA"],
  ["🐭","RATÓN","RA-TÓN"],["🌹","ROSA","RO-SA"]
];

const questions = {
  facil:[
    ["🐱","¿Cuál es la primera sílaba de GATO?",["GA","PA","MA"],"GA"],
    ["🐶","¿Cuál es la primera sílaba de PATO?",["PA","LU","ME"],"PA"],
    ["🌙","¿Cuál es la primera sílaba de LUNA?",["LU","LA","MO"],"LU"],
    ["🏠","¿Cuál es la primera sílaba de CASA?",["CA","CO","SA"],"CA"],
    ["🌹","¿Cuál es la primera sílaba de ROSA?",["RO","RA","RI"],"RO"],
    ["🐭","¿Cuál es la primera sílaba de RATÓN?",["RA","RE","RU"],"RA"]
  ],
  medio:[
    ["⚽","¿Qué sílaba completa PE-LO-TA?",["PE","LO","TA"],"LO"],
    ["🍎","¿Qué sílaba completa MAN-ZA-NA?",["MA","ZA","NA"],"ZA"],
    ["🐸","¿Qué sílaba completa SA-PO?",["SA","PO","PA"],"PO"],
    ["🦋","¿Qué sílaba completa MA-RI-PO-SA?",["MA","PO","SA"],"PO"],
    ["🍌","¿Qué sílaba completa PLÁ-TA-NO?",["PLÁ","TA","NO"],"TA"],
    ["🌻","¿Qué sílaba completa GI-RA-SOL?",["GI","RA","SOL"],"RA"]
  ],
  dificil:[
    ["📚","¿Cuál palabra empieza con MI?",["MESA","MIRAR","PATO"],"MIRAR"],
    ["🌞","¿Cuál palabra empieza con SO?",["SOPA","LUNA","GATO"],"SOPA"],
    ["🐘","¿Cuál palabra empieza con E?",["ELEFANTE","RANA","PATO"],"ELEFANTE"],
    ["🍓","¿Cuál palabra tiene 3 sílabas?",["FRESA","MARIPOSA","PAN"],"MARIPOSA"],
    ["🚲","¿Cuál palabra tiene 2 sílabas?",["BICICLETA","CASA","TELEVISIÓN"],"CASA"],
    ["🎈","¿Cuál palabra tiene 2 sílabas?",["GLOBO","MARIPOSA","TELEFONO"],"GLOBO"]
  ]
};

let currentLevel="facil";
let currentQuestion=0;
let lives=3;
let score=0;
let locked=false;

function showScreen(id){
  document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

function speak(text){
  if("speechSynthesis" in window){
    window.speechSynthesis.cancel();
    const voice=new SpeechSynthesisUtterance(text);
    voice.lang="es-ES";
    voice.rate=.75;
    window.speechSynthesis.speak(voice);
  }
}

function loadLearn(){
  const grid=document.getElementById("syllableGrid");
  grid.innerHTML="";
  syllableGroups.flat().forEach(s=>{
    const b=document.createElement("button");
    b.textContent=s;
    b.onclick=()=>speak(s);
    grid.appendChild(b);
  });
  const examples=document.getElementById("wordExamples");
  examples.innerHTML="";
  words.forEach(w=>{
    const div=document.createElement("div");
    div.className="word";
    div.innerHTML=`${w[0]}<b>${w[1]}</b><small>${w[2]}</small>`;
    div.onclick=()=>speak(w[1]);
    div.style.cursor="pointer";
    examples.appendChild(div);
  });
}

function startGame(level){
  currentLevel=level;
  currentQuestion=0;
  lives=3;
  score=0;
  locked=false;
  document.getElementById("score").textContent=score;
  document.getElementById("lives").textContent=lives;
  document.getElementById("levelLabel").textContent="Nivel "+level;
  showScreen("game");
  showQuestion();
}

function showQuestion(){
  const list=questions[currentLevel];
  if(currentQuestion>=list.length || lives<=0){finishGame();return;}
  locked=false;
  const q=list[currentQuestion];
  document.getElementById("questionEmoji").textContent=q[0];
  document.getElementById("question").textContent=q[1];
  document.getElementById("feedback").textContent="";
  document.getElementById("progressBar").style.width=((currentQuestion/list.length)*100)+"%";
  const box=document.getElementById("options");
  box.innerHTML="";
  q[2].forEach(option=>{
    const b=document.createElement("button");
    b.textContent=option;
    b.onclick=()=>answer(option,b);
    box.appendChild(b);
  });
}

function answer(option,button){
  if(locked)return;
  locked=true;
  const q=questions[currentLevel][currentQuestion];
  const buttons=[...document.querySelectorAll("#options button")];
  buttons.forEach(b=>b.disabled=true);
  if(option===q[3]){
    score+=10;
    button.classList.add("correct");
    document.getElementById("feedback").textContent="🎉 ¡Correcto! +10 puntos";
  }else{
    lives--;
    button.classList.add("wrong");
    const right=buttons.find(b=>b.textContent===q[3]);
    if(right)right.classList.add("correct");
    document.getElementById("feedback").textContent="💡 Casi. La respuesta era "+q[3];
  }
  document.getElementById("score").textContent=score;
  document.getElementById("lives").textContent=lives;
  currentQuestion++;
  setTimeout(showQuestion,1100);
}

function finishGame(){
  showScreen("result");
  const total=questions[currentLevel].length*10;
  const percent=total?score/total:0;
  let starText=percent>=.85?"⭐⭐⭐":percent>=.55?"⭐⭐":"⭐";
  document.getElementById("stars").textContent=starText;
  document.getElementById("finalText").textContent=`Obtuviste ${score} puntos de ${total}. ¡Sigue practicando y aprendiendo!`;
  document.getElementById("progressBar").style.width="100%";
}

document.addEventListener("DOMContentLoaded",loadLearn);
